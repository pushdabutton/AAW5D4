class Array

    def myreduce(&prc, acc)
        if acc.nil
    end

end