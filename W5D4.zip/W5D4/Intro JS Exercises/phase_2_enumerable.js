Array.prototype.myeach = function(callback) {
    for(let i = 0; i < this.length; i++) {
        // debugger
        callback(this[i]); 
    }
    return this;
};

function cb(num) {
    // debugger
    return num * 2;
}

Array.prototype.myMap = function(callback) {
    const mapArr = [];
    // debugger
    this.myeach((ele) => {
        // debugger
        mapArr.push(callback(ele));
    });
    
     
    return mapArr;
};


Array.prototype.myReduce = function(callback, initialValue) {
    let arr = this;
    let acc = initialValue;
    if (!initialValue) {
        acc = this[0];
        arr = this.slice(1);
    }
    
    arr.myeach((ele) => {
        acc = callback(acc, ele);
    });
    return acc;
};