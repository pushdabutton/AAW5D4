Array.prototype.bubbleSort = function() {

    let sorted = false;
    while (!sorted) {
        sorted = true;

        for(let i = 0; i < this.length - 1; i++) {
            if (this[i] > this[i+1]) {
                let temporary = this[i];
                this[i] = this[i+1];
                this[i+1] = temporary;
                sorted = false;
            }
        }

    }
    return this;
}

String.prototype.substrings = function() {
    const substringsArr = [];

    for (let firsti = 0; firsti < this.length; firsti++) {
        for (let secondi = firsti + 1; secondi <= this.length; secondi++) {
            substringsArr.push(this.slice(firsti, secondi));
        }
    }

    return substringsArr;
}

