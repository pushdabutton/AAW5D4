Array.prototype.uniq = function() {
    const uniqArr = [];
    for(let i = 0; i < this.length; i++) {
        if (!uniqArr.includes(this[i])) {
            uniqArr.push(this[i]);
        }
    }
    return uniqArr;
};

Array.prototype.twosum = function() {
    // debugger
    const indexPairs = [];
    for(let firsti = 0; firsti < this.length; firsti++) {
        for(let secondi = firsti + 1; secondi < this.length; secondi++) {
            // debugger
            if (this[firsti] + this[secondi] === 0) {
                indexPairs.push([firsti, secondi]);
            }

        }

    }
    // debugger
    return indexPairs;
};


Array.prototype.transpose = function() {
    const transArr = [];
    for(let row = 0; row < this.length; row++ ) {
        let subbArr = [];
        for(let col = 0; col < this.length; col++) {
            subbArr.push(this[col][row]);
        }
        transArr.push(subbArr);
    }
    return transArr;
}





