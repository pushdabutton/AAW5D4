     function sumRec(arr) {
    if (arr.length === 0) {
        return 0;
    }

    if (arr.length === 1) {
        return arr[0];
    }

    return arr[0] + sumRec(arr.slice(1));
}

function exponent(base, exp) {
    if (exp === 0) {
        return 1;
    }

    if (exp === 1) {
        return base;
    }

    return base * exponent(base, (exp-1));
}

function fibonacci(n) {
    if (n === 1) {
        return [1];
    }
    
    if (n === 2) {
        return [1, 1];
    }

    let fibs = fibonacci(n-1);
    fibs.push(fibs[fibs.length - 1] + fibs[fibs.length - 2]);  
    return fibs;  
}
